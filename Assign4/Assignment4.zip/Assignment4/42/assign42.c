#include "hcs12dp256.h"

const speedStr[] = { 'S', 'p', 'e', 'e', 'd', ':' };
const temperatureStr[] = { 'T', 'e', 'm', 'p', 'e', 'r', 'a', 't', 'u', 'r', 'e', ':', ' ' };
const itoaTable[] = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9' };

char poll_keypad()
{
 	// Map for keys 
 	char keys[4][4]= {{'1','4','7','E'},
		 			  {'2','5','8','0'}, 
					  {'3','6','9','F'},
					  {'A','B','C','D'}};
	//Precomputed lograithm table of 2 for easing tasks a bit				  
	char log2[9] = {0, 0, 1, 0, 2, 0, 0, 0, 3};	
	int i;
 	DDRH=0b00001111; //	 Set direction register of higher bits of port H to input
	DDRM = 0xFF; // Set Direction registers of port M to output
	// Turn off SPI
    PTM = 0x08; 
	SPI1CR1=0; 
	DDRP = 0b00001111; // Set direction register of lower bits of port P to output 
 	
	PTP = 0x01; // Start debouncing the keyboard with first row
	// Continue checking for key presses untill interupted by pressing '0' key	
	while(1)
	{	
	 // Checck for col 1
	 if(PTH&0b00010000)
	 {  
	    return keys[0 ][log2[PTP]];
	 }
	 // Check for col 2
	 if(PTH&0b00100000)
	 {
	    return keys[1 ][log2[PTP]];
	 }
	 //Check for col 3
	 if(PTH&0b01000000)
	 {
	    return keys[2 ][log2[PTP]];
	 }
	 //Check fo col 4
	 if(PTH&0b10000000)
	 {
	    return keys[3 ][log2[PTP]];
	 }  	 	 
	 
	 // Debounce by shifting PTP and reseting to row 1 after the last row
	 if (PTP < 8)  
	 {
	 	PTP = PTP<<1;
	 }
	 else
	 {
	 	PTP = 0x01;
	 }     
	 
	}
}

void displayStrs()
{
 	 int i;
	 
	 LCD_instruction(0x0C); // Turn off cursor and blink
	 LCD_instruction(0x01); // clear screen
	 
	 for (i=0; i<6; i++)
	 {
	  	 LCD_display(speedStr[i]);
	 }
	 
	 LCD_instruction(0xC0); // go to the next line
	
	 for (i=0; i<12; i++)
	 {
	  	 LCD_display(temperatureStr[i]);
	 }	
}

void updateStats(char speed, char temp)
{
 	 LCD_instruction(0x86);
	 LCD_display(itoaTable[speed / 100]); 	  	  	 // 1st digit
	 LCD_display(itoaTable[(speed % 100) / 10]); 	 // 2nd digit
	 LCD_display(itoaTable[(speed % 100) % 10]); 	 // 3rd digit
	 LCD_display('k'); LCD_display('m'); LCD_display('/'); LCD_display('h'); // display "km/h"
	 
	 LCD_instruction(0xCC);
	 //LCD_display(itoaTable[speed / 100]); 	  	 // don't display the 1st digit	 
	 LCD_display(itoaTable[(temp % 100) / 10]); 	 // 2nd digit
	 LCD_display(itoaTable[(temp % 100) % 10]); 	 // 3rd digit
	 LCD_display(0b11011111); LCD_display('C'); 	 // display a 'C' follow by a japanese maru 
}

void main()
{
 	char keyPressed = 0;
	char speed = 100, temp = 99;
	Lcd2PP_Init(); // init the LCD

	displayStrs();	

	while (1)
	{
	 	 updateStats(speed, temp);		  
	 	 keyPressed = poll_keypad();
		 
		 if (keyPressed == 'E' && speed < 255)
		 	speed++;
		 else if (keyPressed == 'D' && speed > 0)
		 	speed--;
	}

	asm("swi");
}