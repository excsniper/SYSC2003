#include "hcs12dp256.h"


void delay(char ms)
{
	 int i, j;
	 for(i=0; i<ms; i++)
	   	for(j=0; j<4000; j++)
		{ asm("nop"); }
}

void main()
{
 	 int i;
 	 DDRT = DDRT | 0b01100000; // DDRs for T & P
	 DDRP = DDRP | 0b00100000;
	 PTP  =  PTP | 0b00100000; // Enable the stepper chip
	 PTT  =  PTT & 0b10011111;	  // reset the stepper
	 
	 
	 for(i=0; i<10; i++)
	 {	    
		//CW
		PTT = 0x40; //10
		delay(10);
		PTT = 0x00; //00
		delay(10); 
		PTT = 0x20; //01
		delay(10);
		PTT = 0x60; //11
		delay(10);
	 }
	
	 for(i=0; i<10; i++)
	 {
	    //CCW
		PTT = 0x60; //11
		delay(10);
		PTT = 0x20; //01
		delay(10);
		PTT = 0x00; //00
		delay(10);
		PTT = 0x40; //10
		delay(10);
	  }
			 
	 asm("swi");
}