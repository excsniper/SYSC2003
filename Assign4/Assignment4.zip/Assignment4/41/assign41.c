/*
*assign41.c A program to detect the keys pressed in the keypad
*
*(assign41.prj, assign41.c, assign41asm.s, DP256reg.s (provided), 
*assign41.SRC, and assign41.s19) Write a program that will detect the keys pressed in 
*the keypad and act accordingly. The keypad contains the following keys: 
*
*/
#include "hcs12dp256.h"
int main()
{

 	// Map for keys 
 	char keys[4][4]= {{'1','4','7','E'},
		 			  {'2','5','8','0'}, 
					  {'3','6','9','F'},
					  {'A','B','C','D'}};
	//Precomputed lograithm table of 2 for easing tasks a bit				  
	char log2[9] = {0, 0, 1, 0, 2, 0, 0, 0, 3};	
	int i;
 	DDRH=0b00001111; //	 Set direction register of higher bits of port H to input
	DDRM = 0xFF; // Set Direction registers of port M to output
	// Turn off SPI
    PTM = 0x08; 
	SPI1CR1=0; 
	DDRP = 0b00001111; // Set direction register of lower bits of port P to output 
 	
	PTP = 0x01; // Start debouncing the keyboard with first row
	// Continue checking for key presses untill interupted by pressing '0' key	
	while(1)
	{	
	
	 // Checck for col 1
	 if(PTH&0b00010000)
	 {  
	  	printf("%c", keys[0 ][log2[PTP]]);
	 }
	 // Check for col 2
	 if(PTH&0b00100000)
	 {
	    printf("%c", keys[1 ][log2[PTP]]);
		// If 0 is pressed then break the loop
		if(PTP == 8)
		{
		 break;
		}
	 }
	 //Check for col 3
	 if(PTH&0b01000000)
	 {
	 	printf("%c", keys[2 ][log2[PTP]]);
	 }
	 //Check fo col 4
	 if(PTH&0b10000000)
	 {
	 	printf("%c", keys[3 ][log2[PTP]]);
	 }  	 	 
	 
	 while(PTH!=0) // Wait for button release !Remove this to support multiple key presses!
	 {
	  	for(i=0; i<8000;i++) // Adding some debounce MAGIC!!
		{
		 	asm("nop");
			asm("nop");
			asm("nop");
			asm("nop");
		}
	 }
	 // Debounce by shifting PTP and reseting to row 1 after the last row
	 if (PTP < 8)  
	 {
	 	PTP = PTP<<1;
		}
	 else{
	 	PTP = 0x01;
		}     
	 
	}
	// End of Program 	    
	asm("swi");
 	return 1;
}
